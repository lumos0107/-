import { useNavigate, useLocation } from 'react-router-dom'
import useStore from '../../store'

const NAV_ITEMS = [
  { path: '/recommend', label: '코스 추천', icon: '🗺️' },
  { path: '/', label: '러닝', icon: '🏃' },
  { path: '/mypage', label: '마이페이지', icon: '👤' },
]

export default function Navbar() {
  const navigate = useNavigate()
  const location = useLocation()
  const { user, logout } = useStore()

  // 로그인/회원가입 화면에서는 네비게이션 바 숨김
  const hideOn = ['/login', '/signup']
  if (!user || hideOn.includes(location.pathname)) return null

  return (
    <div style={{
      position: 'fixed',
      bottom: 0, left: 0, right: 0,
      zIndex: 2000,
      background: 'white',
      borderTop: '1px solid #E5E7EB',
      display: 'flex',
      justifyContent: 'space-around',
      alignItems: 'center',
      padding: '0.5rem 0 0.75rem',
      boxShadow: '0 -4px 16px rgba(0,0,0,0.06)',
    }}>
      {NAV_ITEMS.map((item) => {
        const isActive = location.pathname === item.path
        return (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            style={{
              display: 'flex', flexDirection: 'column',
              alignItems: 'center', gap: '3px',
              background: 'none', border: 'none',
              cursor: 'pointer', padding: '0.4rem 1.2rem',
              borderRadius: '12px',
            }}
          >
            <span style={{ fontSize: '22px' }}>{item.icon}</span>
            <span style={{
              fontSize: '11px',
              fontWeight: isActive ? '600' : '400',
              color: isActive ? '#3B82F6' : '#9CA3AF',
            }}>
              {item.label}
            </span>
            {isActive && (
              <div style={{
                width: '4px', height: '4px',
                borderRadius: '50%', background: '#3B82F6',
              }} />
            )}
          </button>
        )
      })}
    </div>
  )
}
