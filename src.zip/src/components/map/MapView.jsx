import { GoogleMap, useJsApiLoader, Marker, Polyline } from '@react-google-maps/api'
import { useEffect, useRef } from 'react'

const mapContainerStyle = { width: '100%', height: '100%' }
const defaultCenter = { lat: 33.3617, lng: 126.5292 }
const mapOptions = {
  disableDefaultUI: true,
  zoomControl: false,
  streetViewControl: false,
  mapTypeControl: false,
  fullscreenControl: false,
}

export default function MapView({
  currentPosition,
  coursePoints = [],
  obstacles = [],
  places = [],
  followUser = false,
}) {
  const mapRef = useRef(null)

  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_KEY,
  })

  useEffect(() => {
    if (followUser && currentPosition && mapRef.current) {
      mapRef.current.panTo({ lat: currentPosition[0], lng: currentPosition[1] })
    }
  }, [currentPosition, followUser])

  if (!isLoaded) {
    return (
      <div style={{
        width: '100%', height: '100%',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        background: '#F3F4F6', fontSize: '14px', color: '#6B7280',
      }}>
        지도 불러오는 중...
      </div>
    )
  }

  const center = currentPosition
    ? { lat: currentPosition[0], lng: currentPosition[1] }
    : defaultCenter

  return (
    <GoogleMap
      mapContainerStyle={mapContainerStyle}
      center={center}
      zoom={15}
      options={mapOptions}
      onLoad={(map) => { mapRef.current = map }}
    >
      {/* 코스 경로 */}
      {coursePoints.length > 0 && (
        <Polyline
          path={coursePoints.map(([lat, lng]) => ({ lat, lng }))}
          options={{ strokeColor: '#3B82F6', strokeWeight: 4, strokeOpacity: 0.8 }}
        />
      )}

      {/* 현재 위치 */}
      {currentPosition && (
        <Marker
          position={{ lat: currentPosition[0], lng: currentPosition[1] }}
          icon={{
            path: window.google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: '#3B82F6',
            fillOpacity: 1,
            strokeColor: 'white',
            strokeWeight: 3,
          }}
        />
      )}

      {/* 장애물 마커 */}
      {obstacles.map((obs) => (
        <Marker
          key={obs.id}
          position={{ lat: obs.lat, lng: obs.lng }}
          icon={{
            path: window.google.maps.SymbolPath.CIRCLE,
            scale: 6,
            fillColor: '#EF4444',
            fillOpacity: 1,
            strokeColor: 'white',
            strokeWeight: 2,
          }}
          title={obs.type === 'traffic_signal' ? '신호등' : '횡단보도'}
        />
      ))}

      {/* 편의시설 마커 */}
      {places.map((place) => (
        <Marker
          key={place.id}
          position={{ lat: place.lat, lng: place.lng }}
          icon={{
            path: window.google.maps.SymbolPath.CIRCLE,
            scale: 6,
            fillColor: '#10B981',
            fillOpacity: 1,
            strokeColor: 'white',
            strokeWeight: 2,
          }}
          title={place.name}
        />
      ))}
    </GoogleMap>
  )
}
