import { useState, useRef, useCallback } from 'react'

const MIN_WIDTH = 260
const MAX_WIDTH = 420
const DEFAULT_WIDTH = 340

export default function PaceDisplay({
  isRunning,
  currentPace,
  totalDistance,
  elapsedSeconds,
  formatPace,
  formatTime,
  onStart,
  onStop,
}) {
  const distanceKm = (totalDistance / 1000).toFixed(2)

  // 위치 상태 (초기값: 하단 중앙)
  const [pos, setPos] = useState({ x: null, y: null }) // null = 기본 CSS 위치
  const [width, setWidth] = useState(DEFAULT_WIDTH)
  const [isDragging, setIsDragging] = useState(false)
  const [isResizing, setIsResizing] = useState(false)

  const panelRef = useRef(null)
  const dragOffset = useRef({ x: 0, y: 0 })
  const resizeStartX = useRef(0)
  const resizeStartWidth = useRef(0)

  // ── 드래그 ──
  const onDragStart = useCallback((e) => {
    if (e.target.closest('.resize-handle')) return
    e.preventDefault()
    const rect = panelRef.current.getBoundingClientRect()
    dragOffset.current = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    }
    setIsDragging(true)

    const onMove = (e) => {
      setPos({
        x: e.clientX - dragOffset.current.x,
        y: e.clientY - dragOffset.current.y,
      })
    }
    const onUp = () => {
      setIsDragging(false)
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
  }, [])

  // ── 크기 조절 (오른쪽 핸들) ──
  const onResizeStart = useCallback((e) => {
    e.preventDefault()
    e.stopPropagation()
    resizeStartX.current = e.clientX
    resizeStartWidth.current = width
    setIsResizing(true)

    const onMove = (e) => {
      const delta = e.clientX - resizeStartX.current
      const newWidth = Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, resizeStartWidth.current + delta))
      setWidth(newWidth)
    }
    const onUp = () => {
      setIsResizing(false)
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
  }, [width])

  // 위치 스타일 계산
  const positionStyle = pos.x !== null
    ? { left: pos.x, top: pos.y, bottom: 'auto', transform: 'none' }
    : { bottom: '5.5rem', left: '50%', transform: 'translateX(-50%)' }

  return (
    <div
      ref={panelRef}
      onMouseDown={onDragStart}
      style={{
        position: 'absolute',
        ...positionStyle,
        zIndex: 1000,
        width: `${width}px`,
        background: 'rgba(255,255,255,0.97)',
        borderRadius: '20px',
        boxShadow: isDragging
          ? '0 8px 32px rgba(0,0,0,0.18)'
          : '0 4px 24px rgba(0,0,0,0.12)',
        padding: '1.25rem 1.5rem',
        backdropFilter: 'blur(8px)',
        cursor: isDragging ? 'grabbing' : 'grab',
        userSelect: 'none',
        transition: isDragging || isResizing ? 'none' : 'box-shadow 0.15s',
      }}
    >
      {/* 드래그 핸들 표시 */}
      <div style={{
        display: 'flex', justifyContent: 'center', marginBottom: '0.75rem',
      }}>
        <div style={{
          width: '36px', height: '4px',
          background: '#E5E7EB', borderRadius: '2px',
        }} />
      </div>

      {/* 페이스 */}
      <div style={{ textAlign: 'center', marginBottom: '1rem' }}>
        <p style={{ fontSize: '12px', color: '#6B7280', margin: '0 0 2px', letterSpacing: '0.08em' }}>
          현재 페이스
        </p>
        <p style={{ fontSize: '42px', fontWeight: '600', color: '#111827', margin: 0, letterSpacing: '-0.02em' }}>
          {formatPace(currentPace)}
        </p>
        <p style={{ fontSize: '12px', color: '#9CA3AF', margin: '2px 0 0' }}>min/km</p>
      </div>

      {/* 거리 / 시간 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '1.25rem' }}>
        {[
          { label: '거리', value: distanceKm, unit: 'km' },
          { label: '시간', value: formatTime(elapsedSeconds), unit: '경과' },
        ].map((item) => (
          <div key={item.label} style={{
            background: '#F9FAFB', borderRadius: '12px',
            padding: '0.75rem', textAlign: 'center',
          }}>
            <p style={{ fontSize: '11px', color: '#6B7280', margin: '0 0 2px' }}>{item.label}</p>
            <p style={{ fontSize: '22px', fontWeight: '600', color: '#111827', margin: 0 }}>{item.value}</p>
            <p style={{ fontSize: '11px', color: '#9CA3AF', margin: '2px 0 0' }}>{item.unit}</p>
          </div>
        ))}
      </div>

      {/* 시작 / 정지 버튼 */}
      <button
        onMouseDown={(e) => e.stopPropagation()} // 버튼 클릭 시 드래그 방지
        onClick={isRunning ? onStop : onStart}
        style={{
          width: '100%', padding: '0.875rem',
          borderRadius: '14px', border: 'none',
          cursor: 'pointer', fontSize: '15px', fontWeight: '600',
          background: isRunning ? '#EF4444' : '#3B82F6',
          color: 'white', transition: 'opacity 0.15s',
        }}
        onMouseEnter={(e) => e.target.style.opacity = '0.9'}
        onMouseLeave={(e) => e.target.style.opacity = '1'}
      >
        {isRunning ? '러닝 종료' : '러닝 시작'}
      </button>

      {/* 오른쪽 크기 조절 핸들 */}
      <div
        className="resize-handle"
        onMouseDown={onResizeStart}
        style={{
          position: 'absolute',
          right: 0, top: '50%',
          transform: 'translateY(-50%)',
          width: '12px', height: '40px',
          cursor: 'ew-resize',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}
      >
        <div style={{
          width: '4px', height: '24px',
          background: '#D1D5DB', borderRadius: '2px',
        }} />
      </div>
    </div>
  )
}
