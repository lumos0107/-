import { useState, useEffect, useRef } from 'react'

// Haversine 거리 계산 (미터)
function haversineDistance([lat1, lng1], [lat2, lng2]) {
  const R = 6371000
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLng = ((lng2 - lng1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

export default function usePace() {
  const [isRunning, setIsRunning] = useState(false)
  const [currentPace, setCurrentPace] = useState(null)  // 초/km
  const [totalDistance, setTotalDistance] = useState(0) // 미터
  const [elapsedSeconds, setElapsedSeconds] = useState(0)
  const [positions, setPositions] = useState([])        // GPS 기록

  const timerRef = useRef(null)
  const watchIdRef = useRef(null)
  const lastPositionRef = useRef(null)

  // 타이머
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setElapsedSeconds((s) => s + 1)
      }, 1000)
    } else {
      clearInterval(timerRef.current)
    }
    return () => clearInterval(timerRef.current)
  }, [isRunning])

  // GPS 추적
  useEffect(() => {
    if (!isRunning) {
      if (watchIdRef.current) navigator.geolocation.clearWatch(watchIdRef.current)
      return
    }

    watchIdRef.current = navigator.geolocation.watchPosition(
      (pos) => {
        const newPos = [pos.coords.latitude, pos.coords.longitude]
        setPositions((prev) => [...prev, newPos])

        if (lastPositionRef.current) {
          const dist = haversineDistance(lastPositionRef.current, newPos)
          // 5m 이상 이동했을 때만 반영 (GPS 노이즈 필터)
          if (dist > 5) {
            setTotalDistance((d) => d + dist)
          }
        }
        lastPositionRef.current = newPos
      },
      (err) => console.warn('GPS 오류:', err),
      { enableHighAccuracy: true, maximumAge: 1000, timeout: 10000 }
    )

    return () => {
      if (watchIdRef.current) navigator.geolocation.clearWatch(watchIdRef.current)
    }
  }, [isRunning])

  // 페이스 계산 (초/km) - 최근 30초 기준
  useEffect(() => {
    if (positions.length < 2 || elapsedSeconds < 5) return

    // 최근 30초 구간 페이스
    const recentPositions = positions.slice(-10)
    if (recentPositions.length < 2) return

    let recentDist = 0
    for (let i = 1; i < recentPositions.length; i++) {
      recentDist += haversineDistance(recentPositions[i - 1], recentPositions[i])
    }

    if (recentDist > 0) {
      // 초/km
      const pace = (30 / recentDist) * 1000
      setCurrentPace(Math.min(pace, 1200)) // 최대 20분/km 상한
    }
  }, [positions, elapsedSeconds])

  const start = () => {
    setIsRunning(true)
    setTotalDistance(0)
    setElapsedSeconds(0)
    setPositions([])
    setCurrentPace(null)
    lastPositionRef.current = null
  }

  const stop = () => {
    setIsRunning(false)
  }

  const formatPace = (paceSeconds) => {
    if (!paceSeconds) return "--'--\""
    const min = Math.floor(paceSeconds / 60)
    const sec = Math.floor(paceSeconds % 60)
    return `${min}'${String(sec).padStart(2, '0')}"`
  }

  const formatTime = (seconds) => {
    const h = Math.floor(seconds / 3600)
    const m = Math.floor((seconds % 3600) / 60)
    const s = seconds % 60
    if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
  }

  return {
    isRunning,
    currentPace,
    totalDistance,
    elapsedSeconds,
    positions,
    start,
    stop,
    formatPace,
    formatTime,
  }
}
