import { useState, useRef } from 'react'
import { GoogleMap, useJsApiLoader, Marker, Polyline } from '@react-google-maps/api'
import { useNavigate } from 'react-router-dom'
import useStore from '../store'

const mapContainerStyle = { width: '100%', height: '100%' }
const defaultCenter = { lat: 33.3617, lng: 126.5292 }
const mapOptions = {
  disableDefaultUI: true, zoomControl: false,
  mapTypeControl: false, streetViewControl: false, fullscreenControl: false,
}

function generateMockCourses(startLat, startLng, distanceKm) {
  const d = distanceKm * 0.003
  return [
    {
      id: 1, name: '해안 코스', distance: distanceKm,
      estimatedMinutes: Math.round(distanceKm * 6.5),
      avgSlope: 1.2, obstacleCount: 3, score: 92, color: '#3B82F6',
      points: [
        { lat: startLat, lng: startLng },
        { lat: startLat + d * 0.6, lng: startLng + d },
        { lat: startLat + d, lng: startLng + d * 0.4 },
        { lat: startLat + d * 0.3, lng: startLng - d * 0.2 },
        { lat: startLat, lng: startLng },
      ],
    },
    {
      id: 2, name: '공원 코스', distance: distanceKm,
      estimatedMinutes: Math.round(distanceKm * 7),
      avgSlope: 0.5, obstacleCount: 5, score: 85, color: '#10B981',
      points: [
        { lat: startLat, lng: startLng },
        { lat: startLat - d * 0.4, lng: startLng + d * 0.8 },
        { lat: startLat - d * 0.8, lng: startLng + d * 0.3 },
        { lat: startLat - d * 0.5, lng: startLng - d * 0.4 },
        { lat: startLat, lng: startLng },
      ],
    },
    {
      id: 3, name: '도심 코스', distance: distanceKm,
      estimatedMinutes: Math.round(distanceKm * 6),
      avgSlope: 2.1, obstacleCount: 8, score: 78, color: '#F59E0B',
      points: [
        { lat: startLat, lng: startLng },
        { lat: startLat + d * 0.3, lng: startLng - d * 0.6 },
        { lat: startLat - d * 0.3, lng: startLng - d * 0.8 },
        { lat: startLat - d * 0.6, lng: startLng - d * 0.2 },
        { lat: startLat, lng: startLng },
      ],
    },
  ]
}

export default function CourseRecommend() {
  const navigate = useNavigate()
  const setSelectedCourse = useStore((s) => s.setSelectedCourse)
  const mapRef = useRef(null)
  const [startPoint, setStartPoint] = useState(null)
  const [distance, setDistance] = useState('')
  const [courses, setCourses] = useState([])
  const [localSelected, setLocalSelected] = useState(null)
  const [step, setStep] = useState('select_point')
  const [loading, setLoading] = useState(false)

  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_KEY,
  })

  const handleMapClick = (e) => {
    if (step === 'select_point') {
      setStartPoint({ lat: e.latLng.lat(), lng: e.latLng.lng() })
      setStep('input_distance')
    }
  }

  const handleRecommend = async () => {
    if (!distance || isNaN(distance) || Number(distance) <= 0) return
    setLoading(true)
    // TODO: Spring API 연결 시 교체
    await new Promise((r) => setTimeout(r, 1200))
    const mock = generateMockCourses(startPoint.lat, startPoint.lng, Number(distance))
    setCourses(mock)
    setLocalSelected(mock[0])
    setStep('result')
    setLoading(false)
  }

  const handleStartRunning = () => {
    setSelectedCourse(localSelected)
    navigate('/')
  }

  const handleReset = () => {
    setStartPoint(null)
    setDistance('')
    setCourses([])
    setLocalSelected(null)
    setStep('select_point')
  }

  if (!isLoaded) return (
    <div style={{ width: '100vw', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#F3F4F6', fontSize: '14px', color: '#6B7280' }}>
      지도 불러오는 중...
    </div>
  )

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100vh' }}>
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        center={defaultCenter} zoom={13}
        options={mapOptions}
        onClick={handleMapClick}
        onLoad={(map) => { mapRef.current = map }}
      >
        {startPoint && (
          <Marker position={startPoint} icon={{
            path: window.google.maps.SymbolPath.CIRCLE,
            scale: 10, fillColor: '#3B82F6', fillOpacity: 1,
            strokeColor: 'white', strokeWeight: 3,
          }} />
        )}
        {step === 'result' && courses.map((course) => (
          <Polyline key={course.id} path={course.points}
            options={{
              strokeColor: course.color,
              strokeWeight: localSelected?.id === course.id ? 5 : 2.5,
              strokeOpacity: localSelected?.id === course.id ? 0.9 : 0.4,
            }}
            onClick={() => setLocalSelected(course)}
          />
        ))}
      </GoogleMap>

      {step === 'select_point' && (
        <div style={{
          position: 'absolute', top: '1.25rem', left: '50%',
          transform: 'translateX(-50%)', zIndex: 1000,
          background: 'rgba(255,255,255,0.95)', borderRadius: '14px',
          padding: '0.75rem 1.5rem', boxShadow: '0 4px 16px rgba(0,0,0,0.1)',
          fontSize: '14px', fontWeight: '500', color: '#111827', whiteSpace: 'nowrap',
        }}>
          📍 지도에서 출발 지점을 클릭하세요
        </div>
      )}

      {step === 'input_distance' && (
        <div style={{
          position: 'absolute', bottom: '5.5rem', left: '50%',
          transform: 'translateX(-50%)', zIndex: 1000,
          background: 'white', borderRadius: '20px',
          padding: '1.5rem', width: '320px',
          boxShadow: '0 4px 24px rgba(0,0,0,0.12)',
        }}>
          <p style={{ fontSize: '15px', fontWeight: '600', color: '#111827', margin: '0 0 4px' }}>목표 거리 입력</p>
          <p style={{ fontSize: '13px', color: '#6B7280', margin: '0 0 1rem' }}>
            출발점: {startPoint?.lat.toFixed(4)}, {startPoint?.lng.toFixed(4)}
          </p>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '1rem' }}>
            <input
              type="number" value={distance}
              onChange={(e) => setDistance(e.target.value)}
              placeholder="예: 5" min="1" max="30"
              style={{ flex: 1, padding: '0.75rem 1rem', border: '1.5px solid #E5E7EB', borderRadius: '10px', fontSize: '16px', outline: 'none' }}
              onFocus={(e) => e.target.style.borderColor = '#3B82F6'}
              onBlur={(e) => e.target.style.borderColor = '#E5E7EB'}
            />
            <span style={{ fontSize: '15px', color: '#6B7280', fontWeight: '500' }}>km</span>
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <button onClick={handleReset} style={{ flex: 1, padding: '0.75rem', background: '#F3F4F6', color: '#374151', border: 'none', borderRadius: '10px', fontSize: '14px', fontWeight: '500', cursor: 'pointer' }}>
              다시 찍기
            </button>
            <button onClick={handleRecommend} disabled={!distance || loading}
              style={{ flex: 2, padding: '0.75rem', background: !distance ? '#E5E7EB' : '#3B82F6', color: !distance ? '#9CA3AF' : 'white', border: 'none', borderRadius: '10px', fontSize: '14px', fontWeight: '600', cursor: !distance ? 'default' : 'pointer' }}>
              {loading ? '코스 탐색 중...' : '코스 추천받기'}
            </button>
          </div>
        </div>
      )}

      {step === 'result' && (
        <div style={{
          position: 'absolute', bottom: '5.5rem', left: '50%',
          transform: 'translateX(-50%)', zIndex: 1000,
          background: 'white', borderRadius: '20px',
          padding: '1.5rem', width: '340px',
          boxShadow: '0 4px 24px rgba(0,0,0,0.12)',
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <p style={{ fontSize: '15px', fontWeight: '600', color: '#111827', margin: 0 }}>추천 코스</p>
            <button onClick={handleReset} style={{ fontSize: '12px', color: '#6B7280', background: 'none', border: 'none', cursor: 'pointer' }}>다시 설정</button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '1rem' }}>
            {courses.map((course) => (
              <div key={course.id} onClick={() => setLocalSelected(course)} style={{
                padding: '0.875rem 1rem', borderRadius: '12px',
                border: `2px solid ${localSelected?.id === course.id ? course.color : '#E5E7EB'}`,
                background: localSelected?.id === course.id ? `${course.color}10` : 'white',
                cursor: 'pointer', transition: 'all 0.15s',
              }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: course.color }} />
                    <span style={{ fontSize: '14px', fontWeight: '600', color: '#111827' }}>{course.name}</span>
                  </div>
                  <span style={{
                    fontSize: '12px', fontWeight: '600',
                    color: course.score >= 90 ? '#10B981' : course.score >= 80 ? '#3B82F6' : '#F59E0B',
                    background: course.score >= 90 ? '#D1FAE5' : course.score >= 80 ? '#DBEAFE' : '#FEF3C7',
                    padding: '2px 8px', borderRadius: '20px',
                  }}>{course.score}점</span>
                </div>
                <div style={{ display: 'flex', gap: '12px', marginTop: '6px' }}>
                  {[
                    { label: '거리', value: `${course.distance}km` },
                    { label: '예상시간', value: `${course.estimatedMinutes}분` },
                    { label: '경사', value: `${course.avgSlope}%` },
                    { label: '장애물', value: `${course.obstacleCount}개` },
                  ].map((info) => (
                    <div key={info.label}>
                      <p style={{ fontSize: '10px', color: '#9CA3AF', margin: 0 }}>{info.label}</p>
                      <p style={{ fontSize: '12px', color: '#374151', fontWeight: '500', margin: 0 }}>{info.value}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <button onClick={handleStartRunning} style={{
            width: '100%', padding: '0.875rem',
            background: '#3B82F6', color: 'white',
            border: 'none', borderRadius: '12px',
            fontSize: '15px', fontWeight: '600', cursor: 'pointer',
          }}>
            이 코스로 러닝 시작 →
          </button>
        </div>
      )}
    </div>
  )
}
