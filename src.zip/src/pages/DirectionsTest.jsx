import { useState, useRef } from 'react'
import { GoogleMap, useJsApiLoader, Marker, Polyline } from '@react-google-maps/api'

const mapContainerStyle = { width: '100%', height: '100%' }
const defaultCenter = { lat: 33.3617, lng: 126.5292 }
const mapOptions = {
  disableDefaultUI: true,
  zoomControl: true,
}

// Google Encoded Polyline 디코더
function decodePolyline(encoded) {
  const points = []
  let index = 0, lat = 0, lng = 0
  while (index < encoded.length) {
    let b, shift = 0, result = 0
    do {
      b = encoded.charCodeAt(index++) - 63
      result |= (b & 0x1f) << shift
      shift += 5
    } while (b >= 0x20)
    lat += (result & 1) ? ~(result >> 1) : result >> 1

    shift = 0; result = 0
    do {
      b = encoded.charCodeAt(index++) - 63
      result |= (b & 0x1f) << shift
      shift += 5
    } while (b >= 0x20)
    lng += (result & 1) ? ~(result >> 1) : result >> 1

    points.push({ lat: lat / 1e5, lng: lng / 1e5 })
  }
  return points
}

export default function DirectionsTest() {
  const mapRef = useRef(null)
  const [startPoint, setStartPoint] = useState(null)
  const [endPoint, setEndPoint] = useState(null)
  const [routePath, setRoutePath] = useState([])
  const [distance, setDistance] = useState(null)
  const [duration, setDuration] = useState(null)
  const [step, setStep] = useState('start')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const { isLoaded } = useJsApiLoader({
    googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_KEY,
  })

  const handleMapClick = (e) => {
    const lat = e.latLng.lat()
    const lng = e.latLng.lng()
    if (step === 'start') {
      setStartPoint({ lat, lng })
      setRoutePath([])
      setStep('end')
    } else if (step === 'end') {
      setEndPoint({ lat, lng })
      setStep('done')
    }
  }

  const handleGetRoute = async () => {
    if (!startPoint || !endPoint) return
    setLoading(true)
    setError('')

    try {
      const apiKey = process.env.REACT_APP_GOOGLE_MAPS_KEY
      const body = {
        origin: {
          location: { latLng: { latitude: startPoint.lat, longitude: startPoint.lng } }
        },
        destination: {
          location: { latLng: { latitude: endPoint.lat, longitude: endPoint.lng } }
        },
        travelMode: 'WALK',
        routingPreference: 'ROUTING_PREFERENCE_UNSPECIFIED',
        computeAlternativeRoutes: false,
        languageCode: 'ko',
      }

      const res = await fetch(
        `https://routes.googleapis.com/directions/v2:computeRoutes?key=${apiKey}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Goog-FieldMask': 'routes.duration,routes.distanceMeters,routes.polyline.encodedPolyline',
          },
          body: JSON.stringify(body),
        }
      )

      const data = await res.json()
      console.log('Routes API 응답:', JSON.stringify(data, null, 2))

      if (data.routes && data.routes.length > 0) {
        const route = data.routes[0]
        const points = decodePolyline(route.polyline.encodedPolyline)
        setRoutePath(points)

        // 거리
        const meters = route.distanceMeters
        setDistance(meters >= 1000
          ? `${(meters / 1000).toFixed(1)}km`
          : `${meters}m`
        )

        // 시간
        const seconds = parseInt(route.duration.replace('s', ''))
        const min = Math.floor(seconds / 60)
        setDuration(`${min}분`)
      } else {
        setError(`경로를 찾을 수 없습니다. (${JSON.stringify(data.error?.message || data)})`)
      }
    } catch (e) {
      console.error(e)
      setError(`오류 발생: ${e.message}`)
    }

    setLoading(false)
  }

  const handleReset = () => {
    setStartPoint(null)
    setEndPoint(null)
    setRoutePath([])
    setDistance(null)
    setDuration(null)
    setStep('start')
    setError('')
  }

  if (!isLoaded) return (
    <div style={{ width: '100vw', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#F3F4F6', fontSize: '14px', color: '#6B7280' }}>
      지도 불러오는 중...
    </div>
  )

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100vh' }}>
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        center={defaultCenter}
        zoom={14}
        options={mapOptions}
        onClick={handleMapClick}
        onLoad={(map) => { mapRef.current = map }}
      >
        {startPoint && (
          <Marker position={startPoint} icon={{
            path: window.google.maps.SymbolPath.CIRCLE,
            scale: 10, fillColor: '#3B82F6', fillOpacity: 1,
            strokeColor: 'white', strokeWeight: 3,
          }} />
        )}
        {endPoint && (
          <Marker position={endPoint} icon={{
            path: window.google.maps.SymbolPath.CIRCLE,
            scale: 10, fillColor: '#EF4444', fillOpacity: 1,
            strokeColor: 'white', strokeWeight: 3,
          }} />
        )}
        {routePath.length > 0 && (
          <Polyline
            path={routePath}
            options={{ strokeColor: '#3B82F6', strokeWeight: 5, strokeOpacity: 0.8 }}
          />
        )}
      </GoogleMap>

      {/* 상단 안내 */}
      <div style={{
        position: 'absolute', top: '1.25rem', left: '50%',
        transform: 'translateX(-50%)', zIndex: 1000,
        background: 'rgba(255,255,255,0.95)', borderRadius: '14px',
        padding: '0.75rem 1.5rem', boxShadow: '0 4px 16px rgba(0,0,0,0.1)',
        fontSize: '14px', fontWeight: '500', color: '#111827', whiteSpace: 'nowrap',
      }}>
        {step === 'start' && '🔵 출발점을 클릭하세요'}
        {step === 'end' && '🔴 도착점을 클릭하세요'}
        {step === 'done' && '아래 버튼으로 경로를 탐색하세요'}
      </div>

      {/* 하단 패널 */}
      <div style={{
        position: 'absolute', bottom: '2rem', left: '50%',
        transform: 'translateX(-50%)', zIndex: 1000,
        background: 'white', borderRadius: '20px',
        padding: '1.5rem', width: '320px',
        boxShadow: '0 4px 24px rgba(0,0,0,0.12)',
      }}>
        {routePath.length > 0 && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '1rem' }}>
            <div style={{ background: '#EFF6FF', borderRadius: '10px', padding: '0.75rem', textAlign: 'center' }}>
              <p style={{ fontSize: '11px', color: '#6B7280', margin: '0 0 2px' }}>거리</p>
              <p style={{ fontSize: '18px', fontWeight: '600', color: '#1D4ED8', margin: 0 }}>{distance}</p>
            </div>
            <div style={{ background: '#F0FDF4', borderRadius: '10px', padding: '0.75rem', textAlign: 'center' }}>
              <p style={{ fontSize: '11px', color: '#6B7280', margin: '0 0 2px' }}>예상 시간</p>
              <p style={{ fontSize: '18px', fontWeight: '600', color: '#15803D', margin: 0 }}>{duration}</p>
            </div>
          </div>
        )}

        {error && (
          <p style={{ fontSize: '13px', color: '#EF4444', marginBottom: '8px' }}>{error}</p>
        )}

        <div style={{ display: 'flex', gap: '8px' }}>
          <button onClick={handleReset} style={{
            flex: 1, padding: '0.75rem', background: '#F3F4F6', color: '#374151',
            border: 'none', borderRadius: '10px', fontSize: '14px', fontWeight: '500', cursor: 'pointer',
          }}>
            초기화
          </button>
          <button onClick={handleGetRoute} disabled={step !== 'done' || loading} style={{
            flex: 2, padding: '0.75rem',
            background: step !== 'done' ? '#E5E7EB' : '#3B82F6',
            color: step !== 'done' ? '#9CA3AF' : 'white',
            border: 'none', borderRadius: '10px',
            fontSize: '14px', fontWeight: '600',
            cursor: step !== 'done' ? 'default' : 'pointer',
          }}>
            {loading ? '탐색 중...' : '경로 탐색'}
          </button>
        </div>
      </div>
    </div>
  )
}
