import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { login } from '../services/api'
import useStore from '../store'

export default function Login() {
  const navigate = useNavigate()
  const setUser = useStore((s) => s.login)
  const [form, setForm] = useState({ email: '', password: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.email || !form.password) {
      setError('아이디와 비밀번호를 입력해주세요.')
      return
    }
    setLoading(true)
    setError('')
    try {
      const res = await login(form.email, form.password)
      setUser(res.data)
      navigate('/recommend')
    } catch (err) {
      setError(err.response?.data?.message || '로그인에 실패했습니다.')
    }
    setLoading(false)
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: '#F3F4F6',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    }}>
      <div style={{
        background: 'white',
        borderRadius: '20px',
        padding: '2.5rem',
        width: '100%',
        maxWidth: '380px',
        boxShadow: '0 4px 24px rgba(0,0,0,0.08)',
      }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{
            width: '56px', height: '56px',
            background: '#3B82F6', borderRadius: '16px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 12px', fontSize: '28px',
          }}>🏃</div>
          <h1 style={{ fontSize: '22px', fontWeight: '700', color: '#111827', margin: 0 }}>Road Buddy</h1>
          <p style={{ fontSize: '13px', color: '#6B7280', margin: '4px 0 0' }}>제주 러닝 코스 추천</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '12px' }}>
            <label style={{ fontSize: '13px', color: '#374151', fontWeight: '500', display: 'block', marginBottom: '6px' }}>
              아이디 (이메일)
            </label>
            <input
              type="email" name="email"
              value={form.email} onChange={handleChange}
              placeholder="example@email.com"
              style={{
                width: '100%', padding: '0.75rem 1rem',
                border: '1.5px solid #E5E7EB', borderRadius: '10px',
                fontSize: '14px', outline: 'none', boxSizing: 'border-box',
              }}
              onFocus={(e) => e.target.style.borderColor = '#3B82F6'}
              onBlur={(e) => e.target.style.borderColor = '#E5E7EB'}
            />
          </div>

          <div style={{ marginBottom: '8px' }}>
            <label style={{ fontSize: '13px', color: '#374151', fontWeight: '500', display: 'block', marginBottom: '6px' }}>
              비밀번호
            </label>
            <input
              type="password" name="password"
              value={form.password} onChange={handleChange}
              placeholder="비밀번호 입력"
              style={{
                width: '100%', padding: '0.75rem 1rem',
                border: '1.5px solid #E5E7EB', borderRadius: '10px',
                fontSize: '14px', outline: 'none', boxSizing: 'border-box',
              }}
              onFocus={(e) => e.target.style.borderColor = '#3B82F6'}
              onBlur={(e) => e.target.style.borderColor = '#E5E7EB'}
            />
          </div>

          {error && (
            <p style={{ fontSize: '13px', color: '#EF4444', margin: '8px 0' }}>{error}</p>
          )}

          <button type="submit" disabled={loading} style={{
            width: '100%', padding: '0.875rem',
            background: loading ? '#93C5FD' : '#3B82F6',
            color: 'white', border: 'none', borderRadius: '10px',
            fontSize: '15px', fontWeight: '600',
            cursor: loading ? 'default' : 'pointer', marginTop: '12px',
          }}>
            {loading ? '로그인 중...' : '로그인'}
          </button>
        </form>

        <p style={{ textAlign: 'center', fontSize: '13px', color: '#6B7280', marginTop: '1.25rem' }}>
          계정이 없으신가요?{' '}
          <Link to="/signup" style={{ color: '#3B82F6', fontWeight: '600', textDecoration: 'none' }}>
            회원가입
          </Link>
        </p>
      </div>
    </div>
  )
}
