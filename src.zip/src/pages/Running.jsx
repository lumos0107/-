import MapView from '../components/map/MapView'
import PaceDisplay from '../components/running/PaceDisplay'
import usePace from '../hooks/usePace'
import useGeolocation from '../hooks/useGeolocation'
import useStore from '../store'

export default function Running() {
  const { position } = useGeolocation()
  const selectedCourse = useStore((s) => s.selectedCourse)
  const {
    isRunning, currentPace, totalDistance,
    elapsedSeconds, start, stop, formatPace, formatTime,
  } = usePace()

  // 선택된 코스의 points를 [lat, lng] 배열로 변환
  const coursePoints = selectedCourse
    ? selectedCourse.points.map((p) =>
        Array.isArray(p) ? p : [p.lat, p.lng]
      )
    : []

  return (
    <div style={{ position: 'relative', width: '100vw', height: '100vh' }}>
      <MapView
        currentPosition={position}
        coursePoints={coursePoints}
        obstacles={[]}
        places={[]}
        followUser={isRunning}
      />
      <PaceDisplay
        isRunning={isRunning}
        currentPace={currentPace}
        totalDistance={totalDistance}
        elapsedSeconds={elapsedSeconds}
        formatPace={formatPace}
        formatTime={formatTime}
        onStart={start}
        onStop={stop}
      />
    </div>
  )
}
