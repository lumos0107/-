import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { signup } from '../services/api'

export default function Signup() {
  const navigate = useNavigate()
  const [form, setForm] = useState({ email: '', password: '', passwordConfirm: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.email || !form.password || !form.passwordConfirm) {
      setError('모든 항목을 입력해주세요.')
      return
    }
    if (form.password !== form.passwordConfirm) {
      setError('비밀번호가 일치하지 않습니다.')
      return
    }
    if (form.password.length < 6) {
      setError('비밀번호는 6자 이상이어야 합니다.')
      return
    }
    setLoading(true)
    setError('')
    try {
      await signup(form.email, form.password)
      navigate('/login')
    } catch (err) {
      setError(err.response?.data?.message || '회원가입에 실패했습니다.')
    }
    setLoading(false)
  }

  const inputStyle = {
    width: '100%', padding: '0.75rem 1rem',
    border: '1.5px solid #E5E7EB', borderRadius: '10px',
    fontSize: '14px', outline: 'none', boxSizing: 'border-box',
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: '#F3F4F6',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    }}>
      <div style={{
        background: 'white',
        borderRadius: '20px',
        padding: '2.5rem',
        width: '100%',
        maxWidth: '380px',
        boxShadow: '0 4px 24px rgba(0,0,0,0.08)',
      }}>
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{
            width: '56px', height: '56px',
            background: '#3B82F6', borderRadius: '16px',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 12px', fontSize: '28px',
          }}>🏃</div>
          <h1 style={{ fontSize: '22px', fontWeight: '700', color: '#111827', margin: 0 }}>회원가입</h1>
          <p style={{ fontSize: '13px', color: '#6B7280', margin: '4px 0 0' }}>Road Buddy에 오신 걸 환영합니다</p>
        </div>

        <form onSubmit={handleSubmit}>
          {[
            { label: '아이디 (이메일)', name: 'email', type: 'email', placeholder: 'example@email.com' },
            { label: '비밀번호', name: 'password', type: 'password', placeholder: '6자 이상 입력' },
            { label: '비밀번호 확인', name: 'passwordConfirm', type: 'password', placeholder: '비밀번호 재입력' },
          ].map((field) => (
            <div key={field.name} style={{ marginBottom: '12px' }}>
              <label style={{ fontSize: '13px', color: '#374151', fontWeight: '500', display: 'block', marginBottom: '6px' }}>
                {field.label}
              </label>
              <input
                type={field.type} name={field.name}
                value={form[field.name]} onChange={handleChange}
                placeholder={field.placeholder}
                style={inputStyle}
                onFocus={(e) => e.target.style.borderColor = '#3B82F6'}
                onBlur={(e) => e.target.style.borderColor = '#E5E7EB'}
              />
            </div>
          ))}

          {error && (
            <p style={{ fontSize: '13px', color: '#EF4444', margin: '8px 0' }}>{error}</p>
          )}

          <button type="submit" disabled={loading} style={{
            width: '100%', padding: '0.875rem',
            background: loading ? '#93C5FD' : '#3B82F6',
            color: 'white', border: 'none', borderRadius: '10px',
            fontSize: '15px', fontWeight: '600',
            cursor: loading ? 'default' : 'pointer', marginTop: '12px',
          }}>
            {loading ? '가입 중...' : '가입하기'}
          </button>
        </form>

        <p style={{ textAlign: 'center', fontSize: '13px', color: '#6B7280', marginTop: '1.25rem' }}>
          이미 계정이 있으신가요?{' '}
          <Link to="/login" style={{ color: '#3B82F6', fontWeight: '600', textDecoration: 'none' }}>
            로그인
          </Link>
        </p>
      </div>
    </div>
  )
}
