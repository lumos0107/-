import axios from 'axios'

const api = axios.create({
  baseURL: 'http://localhost:8080',
  headers: {
    'Content-Type': 'application/json',
  },
})

export const login = (email, password) =>
  api.post('/api/auth/login', { email, password })

export const signup = (email, password) =>
  api.post('/api/auth/signup', { email, password })

export const recommendCourse = (startLat, startLng, targetDistanceMeters) =>
  api.post('/api/courses/recommend', { startLat, startLng, targetDistanceMeters })

export default api