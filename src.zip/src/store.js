import { create } from 'zustand'

const useStore = create((set) => ({
  // 로그인 상태
  user: null,
  login: (userData) => set({ user: userData }),
  logout: () => set({ user: null, selectedCourse: null }),

  // 선택된 코스 (추천 → 러닝으로 전달)
  selectedCourse: null,
  setSelectedCourse: (course) => set({ selectedCourse: course }),
}))

export default useStore
